<?php

$SERVER = 'stardock.cs.virginia.edu';
$USER = 'cs4750apc5frb';
$PASS = 'fall2013';
$DB = 'cs4750apc5fr';

?>