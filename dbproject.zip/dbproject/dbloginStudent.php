<?php

$SERVER = 'stardock.cs.virginia.edu';
$USER = 'cs4750apc5fra';
$PASS = 'fall2013';
$DB = 'cs4750apc5fr';

?>